<?php
function PokazKontakt() {
    echo '<form action="contact.php" method="post">';
    echo '<label for="email">Twój email:</label><br>';
    echo '<input type="email" id="email" name="email" required><br>';
    echo '<label for="tresc">Treść wiadomości:</label><br>';
    echo '<textarea id="tresc" name="tresc" rows="5" required></textarea><br>';
    echo '<input type="submit" name="wyslij" value="Wyślij wiadomość">';
    echo '</form>';
}

function WyslijMailKontakt() {
    if (empty($_POST['email']) || empty($_POST['tresc'])) {
        echo 'Nie wypełniłeś wszystkich pól.';
        PokazKontakt();
    } else {
        $mail = [
            'recipient' => 'admin@example.com',
            'subject' => 'Wiadomość kontaktowa',
            'body' => $_POST['tresc'],
            'sender' => $_POST['email']
        ];

        $header = "From: Formularz Kontaktowy <{$mail['sender']}>\r\n";
        $header .= "Content-Type: text/plain; charset=utf-8\r\n";

        if (mail($mail['recipient'], $mail['subject'], $mail['body'], $header)) {
            echo 'Wiadomość została wysłana.';
        } else {
            echo 'Wystąpił błąd podczas wysyłania wiadomości.';
        }
    }
}

function PrzypomnijHaslo() {
    if (empty($_POST['email'])) {
        echo 'Podaj swój adres email.';
    } else {
        $email = $_POST['email'];
        $subject = "Przypomnienie hasła";
        $body = "Twoje hasło to: 12345 (przykładowe hasło)";
        $header = "From: admin@example.com\r\n";

        if (mail($email, $subject, $body, $header)) {
            echo 'Hasło zostało wysłane na podany adres email.';
        } else {
            echo 'Wystąpił problem podczas wysyłania hasła.';
        }
    }
}
?>
