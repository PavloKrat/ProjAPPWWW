<?
    $dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$baza = 'moja_strona';
	
	$link = mysql_connect($dbhost,$dbuser,$dbpass);
	if (!$link) echo '<b>przerwane polaczenie </b>';
	if(!mysql_select_db($baza)) echo 'nie wybrano bazy';
	
	$login = 'admin';
    $pass = '1234';
?>