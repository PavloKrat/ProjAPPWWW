<?php
echo "Panel admina jest aktywny.";
?>