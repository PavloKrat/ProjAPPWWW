<?php
// Wyświetla formularz kontaktowy
function PokazKontakt() {
    // Wyświetla formularz z polami do wprowadzenia e-maila i treści wiadomości
    echo '<form action="contact.php" method="post">';
    echo '<label for="email">Twój email:</label><br>';
    echo '<input type="email" id="email" name="email" required><br>';  // Pole do wprowadzenia emaila, wymagane
    echo '<label for="tresc">Treść wiadomości:</label><br>';
    echo '<textarea id="tresc" name="tresc" rows="5" required></textarea><br>';  // Pole do wprowadzenia treści wiadomości, wymagane
    echo '<input type="submit" name="wyslij" value="Wyślij wiadomość">';  // Przycisk do wysłania formularza
    echo '</form>';
}

// Wysyła maila kontaktowego
function WyslijMailKontakt() {
    // Sprawdza, czy pola email i treść wiadomości zostały wypełnione
    if (empty($_POST['email']) || empty($_POST['tresc'])) {
        echo 'Nie wypełniłeś wszystkich pól.';  // Komunikat o błędzie, jeśli brak danych
        PokazKontakt();  // Ponownie wyświetla formularz kontaktowy
    } else {
        // Tworzy tablicę z danymi wiadomości e-mail
        $mail = [
            'recipient' => 'admin@example.com', // zmień na rzeczywisty email odbiorcy
            'subject' => 'Wiadomość kontaktowa', // Temat wiadomości
            'body' => $_POST['tresc'],  // Treść wiadomości z formularza
            'sender' => $_POST['email']  // Adres nadawcy z formularza
        ];

        // Tworzy nagłówki wiadomości
        $header = "From: Formularz Kontaktowy <{$mail['sender']}>\r\n";
        $header .= "Content-Type: text/plain; charset=utf-8\r\n";  // Ustawienie kodowania wiadomości

        // Wysyła wiadomość e-mail
        if (mail($mail['recipient'], $mail['subject'], $mail['body'], $header)) {
            echo 'Wiadomość została wysłana.';  // Komunikat o sukcesie
        } else {
            echo 'Wystąpił błąd podczas wysyłania wiadomości.';  // Komunikat o błędzie
        }
    }
}

// Przypomina hasło (prosta implementacja)
function PrzypomnijHaslo() {
    // Sprawdza, czy podano adres e-mail
    if (empty($_POST['email'])) {
        echo 'Podaj swój adres email.';  // Komunikat o błędzie, jeśli brak adresu e-mail
    } else {
        $email = $_POST['email'];  // Pobiera e-mail z formularza
        $subject = "Przypomnienie hasła";  // Temat wiadomości
        $body = "Twoje hasło to: 12345 (przykładowe hasło)";  // Treść wiadomości z przykładowym hasłem
        $header = "From: admin@example.com\r\n";  // Nagłówki wiadomości

        // Wysyła wiadomość z przypomnieniem hasła
        if (mail($email, $subject, $body, $header)) {
            echo 'Hasło zostało wysłane na podany adres email.';  // Komunikat o sukcesie
        } else {
            echo 'Wystąpił problem podczas wysyłania hasła.';  // Komunikat o błędzie
        }
    }
}
?>

