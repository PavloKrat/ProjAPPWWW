<?php
include('cfg.php');  // Dołącza plik konfiguracyjny (np. ustawienia bazy danych)
include('showpage.php');  // Dołącza plik zawierający funkcję wyświetlania strony (np. PokazPodstrone)

error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);  // Ustawia raportowanie błędów, ignorując NOTICE i WARNING

// Domyślna strona to 'html/glowna.html'
$strona = 'html/glowna.html';

// Sprawdza parametr 'idp' w URL i na tej podstawie ustawia stronę do wyświetlenia
if ($_GET['idp'] == 'mosty') {
    $strona = 'html/mosty.html';  // Jeśli 'idp' to 'mosty', wyświetl 'mosty.html'
} elseif ($_GET['idp'] == 'galeria') {
    $strona = 'html/galeria.html';  // Jeśli 'idp' to 'galeria', wyświetl 'galeria.html'
} elseif ($_GET['idp'] == 'historia') {
    $strona = 'html/historia.html';  // Jeśli 'idp' to 'historia', wyświetl 'historia.html'
} elseif ($_GET['idp'] == 'kontakt') {
    $strona = 'html/kontakt.html';  // Jeśli 'idp' to 'kontakt', wyświetl 'kontakt.html'
} elseif ($_GET['idp'] == 'filmy') {
    $strona = 'html/filmy.html';  // Jeśli 'idp' to 'filmy', wyświetl 'filmy.html'
}

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">  <!-- Ustawia kodowanie strony na UTF-8 -->
    <meta http-equiv="Content-Language" content="pl">  <!-- Ustawia język strony na polski -->
    <meta name="Author" content="Pavlo Krat">  <!-- Informacja o autorze strony -->
    <title>Największe mosty świata</title>  <!-- Tytuł strony wyświetlany na karcie przeglądarki -->
    <link rel="stylesheet" href="css/styl.css">  <!-- Łączy z plikiem CSS do stylowania -->
    <script src="js/kolorujtlo.js" type="text/javascript"></script>  <!-- Łączy z plikiem JavaScript do zmiany tła -->
    <script src="js/timedate.js" type="text/javascript"></script>  <!-- Łączy z plikiem JavaScript do wyświetlania daty i godziny -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  <!-- Łączy z biblioteką jQuery -->
</head>
<body>
    <!-- Menu nawigacyjne -->
    <div class="menu">
        <ul>
            <li><a href="index.php?idp=glowna">Strona Główna</a></li>
            <li><a href="index.php?idp=mosty">Mosty</a></li>
            <li><a href="index.php?idp=galeria">Galeria</a></li>
            <li><a href="index.php?idp=historia">Historia</a></li>
            <li><a href="index.php?idp=kontakt">Kontakt</a></li>
            <li><a href="index.php?idp=filmy">Filmy</a></li>
        </ul>
    </div>

    <!-- Główna zawartość strony -->
    <main>
        <?php
        // Sprawdza, czy plik strony istnieje i włącza go, jeśli tak
        if (file_exists($strona)) {
            include($strona);
        } else {
            echo "<p>Strona nie istnieje.</p>";  // Jeśli plik nie istnieje, wyświetla komunikat o błędzie
        }
        ?>
    </main>

    <?php
    // Wyświetla dane autora strony (imiona, numer indeksu, grupa)
    echo "<h2> </h2>";
    $nr_indeksu = '169300';  // Numer indeksu
    $nr_grupy = 'ISI2';  // Numer grupy
    echo 'Pavlo Krat, ' . $nr_indeksu . ' grupa: ' . $nr_grupy . '<br><br>';
    ?>

    <!-- Stopka strony -->
    <footer>
        <p>&copy; 2024 Największe Mosty Świata.</p>  <!-- Copyright strony -->
    </footer>
</body>
</html>



















