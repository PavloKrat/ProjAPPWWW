<?php
class ZarzadzajKategoriami {
    private $pdo;

    // Konstruktor: Połączenie z bazą danych
    public function __construct($host, $dbname, $user, $password) {
        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Błąd połączenia z bazą danych: " . $e->getMessage());
        }
    }

    // Dodaj kategorię lub podkategorię
    public function DodajKategorie($nazwa, $matka = 0) {
        $sql = "INSERT INTO kategorie (nazwa, matka) VALUES (:nazwa, :matka)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['nazwa' => $nazwa, 'matka' => $matka]);
        echo "Dodano kategorię: $nazwa\n";
    }

    // Usuń kategorię wraz z podkategoriami
    public function UsunKategorie($id) {
        $sql = "DELETE FROM kategorie WHERE id = :id OR matka = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        echo "Usunięto kategorię o ID: $id wraz z podkategoriami\n";
    }

    // Edytuj nazwę kategorii
    public function EdytujKategorie($id, $nowaNazwa) {
        $sql = "UPDATE kategorie SET nazwa = :nazwa WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['nazwa' => $nowaNazwa, 'id' => $id]);
        echo "Zaktualizowano nazwę kategorii o ID: $id na: $nowaNazwa\n";
    }

    // Wyświetl kategorie i podkategorie
    public function PokazKategorie() {
        $sql = "SELECT * FROM kategorie WHERE matka = 0 ORDER BY id LIMIT 100";
        $stmt = $this->pdo->query($sql);
        $kategorieGlowne = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($kategorieGlowne as $kategoria) {
            echo "- " . $kategoria['nazwa'] . " (ID: " . $kategoria['id'] . ")\n";

            $sqlPodkategorie = "SELECT * FROM kategorie WHERE matka = :matka ORDER BY id LIMIT 100";
            $stmtPodkategorie = $this->pdo->prepare($sqlPodkategorie);
            $stmtPodkategorie->execute(['matka' => $kategoria['id']]);
            $podkategorie = $stmtPodkategorie->fetchAll(PDO::FETCH_ASSOC);

            foreach ($podkategorie as $podkategoria) {
                echo "  - " . $podkategoria['nazwa'] . " (ID: " . $podkategoria['id'] . ")\n";
            }
        }
    }
}

// Przykład użycia
try {
    $zarzadzaj = new ZarzadzajKategoriami('localhost', 'sklep', 'root', '');

    // Dodawanie kategorii
    $zarzadzaj->DodajKategorie('Elektronika');
    $zarzadzaj->DodajKategorie('Laptopy', 1);
    $zarzadzaj->DodajKategorie('Smartfony', 1);

    // Wyświetlanie kategorii
    echo "Kategorie:\n";
    $zarzadzaj->PokazKategorie();

    // Edytowanie kategorii
    $zarzadzaj->EdytujKategorie(2, 'Komputery');

    // Usuwanie kategorii
    $zarzadzaj->UsunKategorie(1);
} catch (Exception $e) {
    echo "Wystąpił błąd: " . $e->getMessage();
}

class ZarzadzajProduktami {

    private $db; // Obiekt połączenia z bazą danych

    public function __construct($pdo) {
        $this->db = $pdo;
    }

    // Metoda do dodawania produktu
    public function DodajProdukt($tytul, $opis, $data_wygasniecia, $cena_netto, $vat, $ilosc, $status, $kategoria, $gabaryt, $zdjecie) {
        $sql = "INSERT INTO produkty (tytul, opis, data_utworzenia, data_modyfikacji, data_wygasniecia, cena_netto, podatek_vat, ilosc, status, kategoria, gabaryt, zdjecie)
                VALUES (:tytul, :opis, NOW(), NOW(), :data_wygasniecia, :cena_netto, :vat, :ilosc, :status, :kategoria, :gabaryt, :zdjecie)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'tytul' => $tytul,
            'opis' => $opis,
            'data_wygasniecia' => $data_wygasniecia,
            'cena_netto' => $cena_netto,
            'vat' => $vat,
            'ilosc' => $ilosc,
            'status' => $status,
            'kategoria' => $kategoria,
            'gabaryt' => $gabaryt,
            'zdjecie' => $zdjecie
        ]);
    }

    // Metoda do usuwania produktu
    public function UsunProdukt($id) {
        $sql = "DELETE FROM produkty WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $id]);
    }

    // Metoda do edycji produktu
    public function EdytujProdukt($id, $tytul, $opis, $data_wygasniecia, $cena_netto, $vat, $ilosc, $status, $kategoria, $gabaryt, $zdjecie) {
        $sql = "UPDATE produkty SET tytul = :tytul, opis = :opis, data_modyfikacji = NOW(), data_wygasniecia = :data_wygasniecia,
                cena_netto = :cena_netto, podatek_vat = :vat, ilosc = :ilosc, status = :status, kategoria = :kategoria, 
                gabaryt = :gabaryt, zdjecie = :zdjecie WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'id' => $id,
            'tytul' => $tytul,
            'opis' => $opis,
            'data_wygasniecia' => $data_wygasniecia,
            'cena_netto' => $cena_netto,
            'vat' => $vat,
            'ilosc' => $ilosc,
            'status' => $status,
            'kategoria' => $kategoria,
            'gabaryt' => $gabaryt,
            'zdjecie' => $zdjecie
        ]);
    }

    // Metoda do wyświetlania produktów
    public function PokazProdukty() {
        $sql = "SELECT * FROM produkty ORDER BY data_utworzenia DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Metoda do sprawdzania dostępności produktu
    public function SprawdzDostepnosc($id) {
        $sql = "SELECT status, ilosc, data_wygasniecia FROM produkty WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $id]);
        $produkt = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$produkt) {
            return "Produkt nie istnieje.";
        }

        if ($produkt['status'] != 'dostepny') {
            return "Produkt jest niedostępny.";
        }

        if ($produkt['ilosc'] <= 0) {
            return "Produkt jest wyprzedany.";
        }

        if (strtotime($produkt['data_wygasniecia']) < time()) {
            return "Produkt wygasł.";
        }

        return "Produkt jest dostępny.";
    }
}

// Połączenie z bazą danych
try {
    $pdo = new PDO('mysql:host=localhost;dbname=sklep', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $zarzadzajProduktami = new ZarzadzajProduktami($pdo);

    // Przykładowe użycie
    $zarzadzajProduktami->DodajProdukt(
        "Laptop", 
        "Wydajny laptop do pracy i zabawy", 
        "2025-12-31", 
        3000, 
        23, 
        10, 
        "dostepny", 
        "Elektronika", 
        "Sredni", 
        "images/laptop.jpg"
    );

    $produkty = $zarzadzajProduktami->PokazProdukty();
    print_r($produkty);

} catch (PDOException $e) {
    echo "Błąd połączenia z bazą danych: " . $e->getMessage();
}

?>
