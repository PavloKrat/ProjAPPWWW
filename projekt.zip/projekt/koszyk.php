<?php
session_start(); // Uruchomienie sesji

// Funkcja do dodania produktu do koszyka
function addToCart($productId, $productName, $priceNetto, $vat, $quantity = 1) {
    // Obliczenie ceny brutto
    $priceBrutto = $priceNetto + ($priceNetto * $vat / 100);

    // Jeśli koszyk nie istnieje, inicjalizuj go
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Sprawdź, czy produkt już istnieje w koszyku
    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId]['quantity'] += $quantity; // Dodaj ilość
    } else {
        // Dodaj nowy produkt do koszyka
        $_SESSION['cart'][$productId] = [
            'name' => $productName,
            'price_netto' => $priceNetto,
            'price_brutto' => $priceBrutto,
            'vat' => $vat,
            'quantity' => $quantity
        ];
    }
}

// Funkcja do usuwania produktu z koszyka
function removeFromCart($productId) {
    if (isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]); // Usuń produkt
    }
}

// Funkcja do zmiany ilości produktu
function updateCartQuantity($productId, $quantity) {
    if (isset($_SESSION['cart'][$productId])) {
        if ($quantity > 0) {
            $_SESSION['cart'][$productId]['quantity'] = $quantity; // Aktualizuj ilość
        } else {
            removeFromCart($productId); // Usuń produkt, jeśli ilość <= 0
        }
    }
}

// Funkcja do wyświetlania zawartości koszyka
function showCart() {
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        echo "<p>Koszyk jest pusty.</p>";
        return;
    }

    $totalNetto = 0;
    $totalBrutto = 0;

    echo "<table border='1'>";
    echo "<tr><th>Produkt</th><th>Cena Netto</th><th>Cena Brutto</th><th>VAT</th><th>Ilość</th><th>Suma Brutto</th><th>Akcje</th></tr>";

    foreach ($_SESSION['cart'] as $id => $product) {
        $sumBrutto = $product['price_brutto'] * $product['quantity'];
        $totalNetto += $product['price_netto'] * $product['quantity'];
        $totalBrutto += $sumBrutto;

        echo "<tr>
            <td>{$product['name']}</td>
            <td>{$product['price_netto']} zł</td>
            <td>{$product['price_brutto']} zł</td>
            <td>{$product['vat']}%</td>
            <td>
                <form method='post'>
                    <input type='hidden' name='product_id' value='{$id}'>
                    <input type='number' name='quantity' value='{$product['quantity']}' min='1'>
                    <button type='submit' name='update'>Zmień</button>
                </form>
            </td>
            <td>{$sumBrutto} zł</td>
            <td>
                <form method='post'>
                    <input type='hidden' name='product_id' value='{$id}'>
                    <button type='submit' name='remove'>Usuń</button>
                </form>
            </td>
        </tr>";
    }

    echo "</table>";
    echo "<p>Łączna wartość netto: {$totalNetto} zł</p>";
    echo "<p>Łączna wartość brutto: {$totalBrutto} zł</p>";
}

// Obsługa formularzy
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        addToCart($_POST['product_id'], $_POST['product_name'], $_POST['price_netto'], $_POST['vat'], $_POST['quantity']);
    }

    if (isset($_POST['remove'])) {
        removeFromCart($_POST['product_id']);
    }

    if (isset($_POST['update'])) {
        updateCartQuantity($_POST['product_id'], $_POST['quantity']);
    }
}
?>
