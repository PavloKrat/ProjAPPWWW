<?php
    $login = 'admin'; // Twój login
    $pass = '1234';   // Twoje hasło
    // Dane konfiguracyjne bazy danych
    $dbhost = 'localhost'; // Adres serwera bazy danych
    $dbuser = 'root';      // Nazwa użytkownika bazy danych
    $dbpass = '';          // Hasło do bazy danych
    $baza   = 'moja_strona'; // Nazwa bazy danych

    // Tworzenie połączenia z bazą danych
    $link = new mysqli($dbhost, $dbuser, $dbpass, $baza);

    // Sprawdzanie połączenia
    if ($link->connect_error) {
        die("Połączenie nie powiodło się: " . $link->connect_error);
    }

    // Ustawienie kodowania znaków na UTF-8
    $link->set_charset("utf8");

?>