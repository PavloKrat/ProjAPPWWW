<?php
echo "Panel admina jest aktywny.";
?>

<?php
function ListaPodstron()
{
    $query = "SELECT * FROM page_list ORDER BY id DESC";
    $result = mysqli_query($GLOBALS['conn'], $query); // Połączenie z bazą danych

    $wynik = '<table border="1">
                <tr><th>ID</th><th>Tytuł</th><th>Opcje</th></tr>';
    while ($row = mysqli_fetch_assoc($result)) {
        $wynik .= '<tr>
                        <td>' . $row['id'] . '</td>
                        <td>' . htmlspecialchars($row['tytul']) . '</td>
                        <td>
                            <a href="admin.php?akcja=edytuj&id=' . $row['id'] . '">Edytuj</a> | 
                            <a href="admin.php?akcja=usun&id=' . $row['id'] . '">Usuń</a>
                        </td>
                   </tr>';
    }
    $wynik .= '</table>';
    return $wynik;
}
?>

<?php
function EdytujPodstrone($id)
{
    $query = "SELECT * FROM page_list WHERE id = " . intval($id);
    $result = mysqli_query($GLOBALS['conn'], $query);
    $row = mysqli_fetch_assoc($result);

    if (!$row) {
        return '<p>Nie znaleziono podstrony!</p>';
    }

    $wynik = '
    <form method="post" action="">
        <input type="hidden" name="id" value="' . htmlspecialchars($row['id']) . '">
        <label>Tytuł: <input type="text" name="tytul" value="' . htmlspecialchars($row['tytul']) . '"></label><br>
        <label>Treść: <textarea name="tresc">' . htmlspecialchars($row['tresc']) . '</textarea></label><br>
        <label>Aktywna: <input type="checkbox" name="aktywna" ' . ($row['aktywna'] ? 'checked' : '') . '></label><br>
        <input type="submit" name="zapisz" value="Zapisz">
    </form>';

    if (isset($_POST['zapisz'])) {
        $tytul = $_POST['tytul'];
        $tresc = $_POST['tresc'];
        $aktywna = isset($_POST['aktywna']) ? 1 : 0;

        $update = "UPDATE page_list SET tytul='$tytul', tresc='$tresc', aktywna=$aktywna WHERE id=" . intval($id);
        mysqli_query($GLOBALS['conn'], $update);
        header('Location: admin.php');
        exit();
    }

    return $wynik;
}
?>

<?php
function DodajNowaPodstrone()
{
    if (isset($_POST['dodaj'])) {
        $tytul = $_POST['tytul'];
        $tresc = $_POST['tresc'];
        $aktywna = isset($_POST['aktywna']) ? 1 : 0;

        $insert = "INSERT INTO page_list (tytul, tresc, aktywna) VALUES ('$tytul', '$tresc', $aktywna)";
        mysqli_query($GLOBALS['conn'], $insert);
        header('Location: admin.php');
        exit();
    }

    $wynik = '
    <form method="post" action="">
        <label>Tytuł: <input type="text" name="tytul"></label><br>
        <label>Treść: <textarea name="tresc"></textarea></label><br>
        <label>Aktywna: <input type="checkbox" name="aktywna"></label><br>
        <input type="submit" name="dodaj" value="Dodaj">
    </form>';

    return $wynik;
}
?>

<?php
function UsunPodstrone($id)
{
    $delete = "DELETE FROM page_list WHERE id = " . intval($id);
    mysqli_query($GLOBALS['conn'], $delete);
    header('Location: admin.php');
    exit();
}
?>

