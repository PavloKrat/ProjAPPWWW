<?php
include('cfg.php');  // Dołącza plik konfiguracyjny (prawdopodobnie z połączeniem do bazy danych)

// Funkcja wyświetlająca stronę o podanym ID
function PokazPodstrone($id) {
    $id_clear = htmlspecialchars($id);  // Oczyszcza ID, aby zapobiec atakom XSS (złośliwe skrypty)

    // Tworzy zapytanie SQL, aby pobrać stronę o danym ID z tabeli 'page_list'
    $query = "SELECT * FROM page_list WHERE id='$id_clear' LIMIT 1";
    $result = mysql_query($query);  // Wykonuje zapytanie do bazy danych
    $row = mysql_fetch_array($result);  // Pobiera wynik zapytania w postaci tablicy

    // Tworzy zapytanie, aby pobrać 10 pierwszych stron (choć nie jest ono wykorzystywane w tym kodzie)
    $query = "SELECT * FROM page_list LIMIT 0, 10";

    // Sprawdza, czy strona o podanym ID została znaleziona w bazie danych
    if (empty($row['id'])) {
        $web = '[nie_znaleziono_strony]';  // Jeśli strona nie została znaleziona, zwraca komunikat o błędzie
    } else {
        $web = $row['page_content'];  // Jeśli strona została znaleziona, zwraca jej zawartość
    }

    return $web;  // Zwraca zawartość strony lub komunikat o błędzie
}
?>
